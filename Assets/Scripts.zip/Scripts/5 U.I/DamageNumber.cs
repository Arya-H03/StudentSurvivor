using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class DamageNumber : MonoBehaviour
{
   
    [SerializeField] GameObject enemy;
    [SerializeField] TMP_Text damageNumberText;

    //public static void Create(Vector3 position,float damageAmount)
    //{
    //    Instantiate
    //}
    
    //void Start()
    //{
       
      
    //}

    
    //void Update()
    //{
        

             
    //}


  
}
