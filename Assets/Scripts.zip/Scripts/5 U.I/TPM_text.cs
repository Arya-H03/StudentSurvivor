﻿internal class TPM_text
{
}